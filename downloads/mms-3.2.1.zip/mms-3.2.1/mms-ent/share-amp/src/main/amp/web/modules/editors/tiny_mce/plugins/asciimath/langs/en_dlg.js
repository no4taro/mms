tinyMCE.addI18n('en.asciimath_dlg',{
title:'Math Symbols'
});
