#!/bin/bash
sh ./clean.sh
sh ./run.sh
