package gov.nasa.jpl.view_repo.util;

public class EmsTransaction {
}
