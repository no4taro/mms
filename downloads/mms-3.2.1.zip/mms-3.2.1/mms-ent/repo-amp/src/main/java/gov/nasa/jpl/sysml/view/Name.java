package gov.nasa.jpl.sysml.view;

/**
 * a Name to embed in a {@link View}
 *
 */
public interface Name<E> extends Viewable<E> {
}
