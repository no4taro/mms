package gov.nasa.jpl.sysml.view;

public interface Value< E > extends Viewable< E > {

}
