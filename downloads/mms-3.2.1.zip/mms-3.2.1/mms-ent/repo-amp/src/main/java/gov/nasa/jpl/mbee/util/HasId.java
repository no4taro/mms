package gov.nasa.jpl.mbee.util;

public interface HasId<I> {
  I getId();
}
