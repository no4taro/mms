package gov.nasa.jpl.sysml.view;

public interface Id< E > extends Viewable< E > {

}
