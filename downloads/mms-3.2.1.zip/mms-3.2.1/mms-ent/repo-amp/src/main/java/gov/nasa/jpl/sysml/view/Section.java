package gov.nasa.jpl.sysml.view;

public interface Section< E > extends List< E > {
    String getTitle();
}
