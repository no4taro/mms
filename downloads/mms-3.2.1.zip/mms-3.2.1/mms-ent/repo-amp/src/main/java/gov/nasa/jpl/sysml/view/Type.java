package gov.nasa.jpl.sysml.view;

public interface Type< E > extends Viewable< E > {

}
