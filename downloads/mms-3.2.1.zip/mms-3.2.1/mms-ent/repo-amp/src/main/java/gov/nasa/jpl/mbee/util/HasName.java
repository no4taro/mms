package gov.nasa.jpl.mbee.util;

public interface HasName<N> {
  N getName();
}
