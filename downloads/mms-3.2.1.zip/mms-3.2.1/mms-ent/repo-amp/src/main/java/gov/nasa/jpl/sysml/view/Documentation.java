package gov.nasa.jpl.sysml.view;

public interface Documentation< E > extends Viewable< E > {

}
