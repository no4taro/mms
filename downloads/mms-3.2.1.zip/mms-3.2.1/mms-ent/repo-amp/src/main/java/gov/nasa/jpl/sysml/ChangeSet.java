package gov.nasa.jpl.sysml;

public interface ChangeSet {

}
