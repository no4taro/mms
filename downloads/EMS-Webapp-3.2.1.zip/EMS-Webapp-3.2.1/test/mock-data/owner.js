var getOwner = function (){
        return {
            "_siteCharacterizationId": "vetest",
            "_qualifiedId": "/vetest/PROJECT-21bbdceb-a188-45d9-a585-b30bba346175/_17_0_5_1_407019f_1402422593316_200143_16117/_17_0_5_1_407019f_1402422683509_36078_16169/MMS_1442345799882_df10c451-ab83-4b99-8e40-0a8e04b38b9d",
            "_qualifiedName": "/vetest/VETest/adasdsddd3/Test64 sgfa/test opaquepara",
            "sysmlId": "MMS_1442345799882_df10c451-ab83-4b99-8e40-0a8e04b38b9d",
            "_editable": true,
            "_creator": "dlam",
            "_modified": "2015-12-17T12:45:15.316-0800",
            "_modifier": "dlam",
            "_created": "2015-12-17T11:45:15.316-0800",
            "name": "test opaquepara",
            "documentation": "",
            "ownerId": "_17_0_5_1_407019f_1402422683509_36078_16169",
            "_appliedStereotypeIds": [
                "_17_0_1_232f03dc_1325612611695_581988_21583"
            ],
            "_read": "2016-02-09T13:57:59.842-0800",
            "_displayedElements": ["MMS_1442345799882_df10c451-ab83-4b99-8e40-0a8e04b38b9d"],
            "_contents": {
                "operand": [{
                    "type": "InstanceValue",
                    "instanceId": "MMS_1442345802606_38e60e27-d4b1-47ce-b876-840a2b7e9b3c"
                }],
                "type": "Expression"
            },
            "_allowedElements": [],
            "_contains": [],
            "type": "Class"
        };
};