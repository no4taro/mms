//"use strict";
//
//describe('When writing a test with karma', function () {
//    beforeEach(function () {
//        module('mmsApp');
//    });
//    it('should always follow this folder structure', function () {
//        expect(true).toBeTruthy();
//    });
//    it('tests should also be organized into files that correspond to what they\'re testing',function() {
//        expect(true).toBeTruthy();
//    })
//});