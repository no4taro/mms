package gov.nasa.jpl.mbee.mdk.generator.graphs;

public interface UndirectedHyperGraph<VertexType, EdgeType extends UndirectedHyperEdge<VertexType>> extends
        Graph<VertexType, EdgeType> {
}
