package gov.nasa.jpl.mbee.mdk.generator.graphs;

public interface UndirectedHyperEdge<VertexType> extends Edge<VertexType> {

}
