package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes;

/**
 * Created by igomes on 8/23/16.
 */
public class FigureClass extends PresentationElementClass {
    @Override
    public String getID() {
        return "_18_5_2_8bf0285_1506035630029_725905_15942";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::Figure";
    }
}
