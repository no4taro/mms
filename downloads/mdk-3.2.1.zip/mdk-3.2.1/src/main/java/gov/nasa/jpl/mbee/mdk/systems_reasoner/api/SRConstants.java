package gov.nasa.jpl.mbee.mdk.systems_reasoner.api;

public class SRConstants {
    public static final String ASPECT_STEREOTYPE_ID = "_18_0_2_407019f_1449688347122_736579_14412";
}
