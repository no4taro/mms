package gov.nasa.jpl.mbee.mdk.api.stream;

public class MDKCollectors {
    public static ArrayNodeCollector toArrayNode() {
        return new ArrayNodeCollector();
    }
}
