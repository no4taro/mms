package gov.nasa.jpl.mbee.mdk.api.incubating.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * Created by igomes on 9/28/16.
 */
@Target(ElementType.METHOD)
public @interface SessionManaged {
}
