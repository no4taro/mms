package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes.properties;

/**
 * Created by igomes on 8/23/16.
 */
public class GeneratedFromElementProperty extends PresentationElementClassProperty {
    @Override
    public String getID() {
        return "_17_0_5_1_407019f_1430628376067_525763_12104";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::OpaqueSection::generatedFromElement";
    }
}
