package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes;

/**
 * Created by igomes on 8/23/16.
 */
public class OpaqueParagraphClass extends PresentationElementClass {
    @Override
    public String getID() {
        return "_17_0_5_1_407019f_1430628197332_560980_11953";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::OpaqueParagraph";
    }
}
