package gov.nasa.jpl.mbee.mdk.docgen.view;

/**
 * @author dlam
 * @model
 */
public interface ListItem extends HasContent {

}
