package gov.nasa.jpl.mbee.mdk.docgen.view;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Table Row</b></em>'. <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see DocGenViewPackage#getTableRow()
 */
public interface TableRow extends HasContent {
} // TableRow
