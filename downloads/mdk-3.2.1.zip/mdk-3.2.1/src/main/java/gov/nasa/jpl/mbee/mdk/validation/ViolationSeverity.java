package gov.nasa.jpl.mbee.mdk.validation;

public enum ViolationSeverity {
    WARNING, ERROR, INFO, FATAL, DEBUG
}
