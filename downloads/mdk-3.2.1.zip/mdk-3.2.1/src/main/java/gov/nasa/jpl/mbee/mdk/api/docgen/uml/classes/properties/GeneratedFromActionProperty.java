package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes.properties;

/**
 * Created by igomes on 8/23/16.
 */
public class GeneratedFromActionProperty extends PresentationElementClassProperty {
    @Override
    public String getID() {
        return "_17_0_5_1_407019f_1431903785758_545971_12087";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::PresentationElement::generatedFromAction";
    }
}
