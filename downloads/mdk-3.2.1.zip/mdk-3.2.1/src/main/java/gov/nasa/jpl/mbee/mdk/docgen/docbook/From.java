package gov.nasa.jpl.mbee.mdk.docgen.docbook;

public enum From {
    NAME, DOCUMENTATION, DVALUE
}
