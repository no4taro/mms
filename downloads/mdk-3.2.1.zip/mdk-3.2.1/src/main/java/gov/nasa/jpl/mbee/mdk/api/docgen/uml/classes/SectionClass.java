package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes;

/**
 * Created by igomes on 8/23/16.
 */
public class SectionClass extends PresentationElementClass {

    @Override
    public String getID() {
        return "_18_0_2_407019f_1435683487667_494971_14412";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::Section";
    }
}
