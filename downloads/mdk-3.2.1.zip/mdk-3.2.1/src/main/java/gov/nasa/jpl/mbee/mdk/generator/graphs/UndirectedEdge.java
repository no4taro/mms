package gov.nasa.jpl.mbee.mdk.generator.graphs;

public interface UndirectedEdge<VertexType> extends UndirectedHyperEdge<VertexType> {

}
