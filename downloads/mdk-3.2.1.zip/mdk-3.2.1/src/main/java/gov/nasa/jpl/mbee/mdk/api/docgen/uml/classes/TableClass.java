package gov.nasa.jpl.mbee.mdk.api.docgen.uml.classes;

/**
 * Created by igomes on 8/23/16.
 */
public class TableClass extends PresentationElementClass {
    @Override
    public String getID() {
        return "_17_0_5_1_407019f_1431903724067_825986_11992";
    }

    @Override
    public String getQualifiedName() {
        return "SysML Extensions::DocGen::Presentation Elements::Table";
    }
}
