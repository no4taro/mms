/**
 * this was something added by seung, shouldn't really be used and anything that
 * needs graph stuff should be using jgrapht unfortunately docgen is currently
 * using these (for topological sort) when parsing viewpoint activities, so need
 * to convert those first.
 **/
package gov.nasa.jpl.mbee.mdk.generator.graphs;