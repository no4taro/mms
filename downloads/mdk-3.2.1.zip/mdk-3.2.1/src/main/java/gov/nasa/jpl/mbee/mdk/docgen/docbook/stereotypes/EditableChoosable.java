package gov.nasa.jpl.mbee.mdk.docgen.docbook.stereotypes;

/**
 * Created by igomes on 8/25/16.
 */
public interface EditableChoosable {

    Boolean isEditable();

    void setEditable(Boolean editable);
}
