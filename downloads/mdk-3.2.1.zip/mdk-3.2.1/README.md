# MagicDraw Model Development Kit (MDK)

[ ![Download](https://api.bintray.com/packages/openmbee/maven/mdk/images/download.svg) ](https://bintray.com/openmbee/maven/mdk/_latestVersion)[![CircleCI](https://circleci.com/gh/Open-MBEE/mdk.svg?style=svg)](https://circleci.com/gh/Open-MBEE/mdk)